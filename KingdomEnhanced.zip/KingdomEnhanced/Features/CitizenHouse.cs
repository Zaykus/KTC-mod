﻿namespace KingdomEnhanced.Features
{
    internal class CitizenHouse
    {
    }
}